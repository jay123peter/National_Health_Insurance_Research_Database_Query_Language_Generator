$(document).ready(function(){
  $("#firstclinic").click(function(){
    $("#demo").load("http://140.117.171.242/SQLGenerator/firstclinic.html");
  });
});
